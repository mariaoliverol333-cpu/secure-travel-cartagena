# Secure Travel Cartagena — Sistema de Reservas

Plugin de WordPress desarrollado en PHP para la gestión de reservas de habitaciones de **Secure Travel Cartagena**.

Permite a la recepcionista consultar disponibilidad, calcular precios y gestionar reservas, y al administrador controlar el inventario de habitaciones, los precios y los informes de ocupación. Incluye una pasarela de pagos simulada.

**Prueba técnica — Desarrollador Junior**
Aspirante: Maria Olivero

---

## Requisitos

- WordPress 6.0 o superior
- PHP 7.4 o superior
- MySQL / MariaDB

## Instalación

1. Descargar o clonar este repositorio.
2. Copiar la carpeta `secure-travel-cartagena` dentro de `wp-content/plugins/`.
3. En el panel de WordPress ir a **Plugins** y activar **Secure Travel Cartagena - Sistema de Reservas**.

Al activarse, el plugin crea automáticamente:

- Las cuatro tablas del sistema.
- Los roles **Administrador de Hotel** y **Recepcionista**.
- Siete habitaciones de ejemplo (Sencilla, Doble y Familiar) para poder probar el sistema de inmediato.

No requiere configuración adicional ni plugins de terceros.

---

## Cumplimiento de los requerimientos

### Rol: Recepcionista

| Requerimiento | Dónde se implementa |
|---|---|
| Consultar listado de habitaciones disponibles | Menú **Disponibilidad** — búsqueda por rango de fechas y filtro por tipo |
| Calcular el precio total para un cliente | Menú **Nueva reserva** — cálculo en vivo según noches, habitaciones y tipo de cliente |
| Registrar una reserva | Menú **Nueva reserva** |
| Eliminar una reserva indicando el número de habitación | Menú **Eliminar reserva** — búsqueda por número de habitación y confirmación |

### Rol: Administrador

| Requerimiento | Dónde se implementa |
|---|---|
| CRUD de habitaciones | Menú **Habitaciones** — crear, listar, editar, activar/desactivar y eliminar |
| Informe de habitaciones disponibles y reservadas | Menú **Informes** — ocupación por periodo, por tipo y totales facturados |

### Pasarela de pagos (simulada)

| Requerimiento | Dónde se implementa |
|---|---|
| Registrar un pago para una reserva | Botón **Pagar** en el listado de reservas |
| Asociar el pago a la reserva | Tabla `pagos` con clave `reserva_id`; admite pagos parciales |

---

## Roles y permisos

| Acción | Administrador | Recepcionista |
|---|:---:|:---:|
| Consultar disponibilidad | Sí | Sí |
| Calcular precio y registrar reservas | Sí | Sí |
| Eliminar reservas | Sí | Sí |
| Registrar pagos | Sí | Sí |
| CRUD de habitaciones y precios | Sí | **No** |
| Ver informes | Sí | **No** |

Cada requerimiento se tradujo en una capacidad propia (`stc_consultar_disponibilidad`, `stc_registrar_reservas`, `stc_gestionar_habitaciones`, etc.). Las capacidades se verifican en dos niveles: al registrar cada menú, para que WordPress lo oculte a quien no lo tenga; y al inicio de cada vista mediante `stc_exigir_permiso()`, de modo que el control no dependa únicamente de ocultar opciones en la interfaz.

El rol nativo `administrator` de WordPress recibe todas las capacidades del sistema, para facilitar la revisión sin crear usuarios adicionales.

### Cómo probar los roles

1. Ir a **Usuarios → Añadir nuevo**.
2. Crear un usuario con el rol **Recepcionista**.
3. Iniciar sesión con ese usuario: los menús *Habitaciones* e *Informes* no aparecen, y el acceso directo por URL queda bloqueado.

---

## Reglas de negocio

### Control de disponibilidad

Dos estadías se cruzan cuando:

```
llegada_existente < salida_nueva   Y   salida_existente > llegada_nueva
```

Se usan comparaciones estrictas (`<` y `>`) de forma intencional: si un huésped sale el mismo día que otro llega, la habitación se considera disponible, tal como funciona la operación real de un hotel.

La validación se ejecuta al listar habitaciones y **nuevamente en el servidor al guardar la reserva**, para evitar que dos recepcionistas reserven la misma habitación de forma simultánea.

### Cálculo del precio

```
subtotal  = suma(precio_noche de cada habitación) × número de noches
descuento = subtotal × porcentaje según tipo de cliente
total     = subtotal − descuento
```

Los clientes **frecuentes** reciben un descuento del 10 % (constante `STC_DESCUENTO_FRECUENTE`); los **esporádicos** pagan tarifa plena. El cálculo se muestra en vivo en el navegador como ayuda visual, pero el valor que se guarda siempre se recalcula en el servidor.

### Validaciones de la reserva

- Nombre, documento y tipo de cliente obligatorios; correo con formato válido.
- La fecha de salida debe ser posterior a la de llegada.
- La fecha de llegada no puede estar en el pasado.
- Debe seleccionarse al menos una habitación.
- La cantidad de huéspedes no puede superar la capacidad sumada de las habitaciones elegidas.
- Todas las habitaciones deben estar libres en el rango solicitado.

### Pasarela de pagos

El flujo reproduce el de una pasarela real sin realizar conexiones externas: valida los datos de la tarjeta (16 dígitos, CVV de 3 o 4 dígitos, vencimiento en formato MM/AA), simula la respuesta de la entidad, genera una referencia única de transacción y registra el pago asociado a la reserva.

Se admiten **pagos parciales**: la reserva pasa a estado `abonada` mientras quede saldo y a `pagada` cuando se cubre el total.

**Datos de prueba:**

| Caso | Tarjeta | Resultado |
|---|---|---|
| Aprobado | `4111 1111 1111 1111` | Genera referencia y actualiza el estado |
| Rechazado | `4111 1111 1111 0000` | Rechazo de la entidad, no se registra el pago |

Cualquier tarjeta de 16 dígitos es aprobada, salvo las terminadas en `0000`, que simulan un rechazo para poder verificar el manejo de errores.

---

## Modelo de datos

| Tabla | Contenido |
|---|---|
| `wp_stc_habitaciones` | Inventario: número, tipo, capacidad, precio por noche, estado |
| `wp_stc_reservas` | Cabecera: cliente, tipo de cliente, fechas, huéspedes, subtotal, descuento, total, estado |
| `wp_stc_reserva_habitaciones` | Detalle: qué habitaciones incluye cada reserva y a qué precio |
| `wp_stc_pagos` | Pagos aprobados, con referencia y asociados a una reserva |

**Por qué una tabla de detalle.** El enunciado exige almacenar la *cantidad de habitaciones* de cada reserva, de modo que una reserva puede incluir varias. Guardar ese listado en un solo campo impediría validar la disponibilidad habitación por habitación. La tabla de detalle permite además conservar el precio vigente al momento de reservar, para que un cambio de tarifa posterior no altere reservas ya registradas.

**Por qué tablas propias y no Custom Post Types.** Un sistema de reservas consulta constantemente cruces de rangos de fechas. Modelarlo con `post_meta` obligaría a múltiples JOINs sobre una tabla genérica y con valores almacenados como texto. Con tablas propias e índices sobre las fechas y las claves foráneas, la validación de disponibilidad se resuelve en una sola consulta.

---

## Estructura del proyecto

```
secure-travel-cartagena/
├── secure-travel-cartagena.php      # Archivo principal: constantes, carga y hooks
├── includes/                        # Lógica de negocio (sin HTML)
│   ├── instalador.php               # Tablas, roles y datos iniciales
│   ├── funciones-habitaciones.php   # CRUD de habitaciones
│   ├── funciones-reservas.php       # Disponibilidad, precios, reservas
│   ├── funciones-pagos.php          # Pasarela simulada
│   └── menus.php                    # Registro de menús y utilidades de vista
├── admin/                           # Vistas del panel (HTML)
│   ├── vista-disponibilidad.php
│   ├── vista-nueva-reserva.php
│   ├── vista-reservas.php
│   ├── vista-eliminar-reserva.php
│   ├── vista-habitaciones.php
│   ├── vista-informe.php
│   └── vista-pago.php
├── assets/css/admin.css
└── README.md
```

La separación entre `includes/` (lógica) y `admin/` (presentación) permite que las reglas de negocio se puedan reutilizar o probar de forma independiente de la interfaz.

---

## Seguridad

- **Inyección SQL:** todas las consultas se construyen con `$wpdb->prepare()`.
- **XSS:** las entradas se sanitizan (`sanitize_text_field`, `sanitize_email`, `intval`, `floatval`) y las salidas se escapan (`esc_html`, `esc_attr`, `esc_url`, `esc_textarea`).
- **CSRF:** todos los formularios y acciones destructivas usan nonces (`wp_nonce_field`, `wp_verify_nonce`).
- **Control de acceso:** verificación de capacidades en el registro del menú y al inicio de cada vista.
- **Acceso directo:** todos los archivos verifican la constante `ABSPATH`.

---

## Decisiones de diseño

- **Las habitaciones no se eliminan si tienen reservas asociadas.** El sistema lo impide y sugiere desactivarlas, para no dejar registros históricos inconsistentes.
- **Eliminar una reserva borra también sus pagos** y libera las habitaciones, según lo solicitado en el enunciado. La eliminación exige confirmación previa.
- **El precio se recalcula siempre en el servidor.** El cálculo en el navegador es únicamente una ayuda visual para el recepcionista.

---

## Posibles mejoras

- Formulario público de reservas en el front mediante shortcode.
- Edición de reservas ya registradas.
- Envío de correo de confirmación al cliente con `wp_mail()`.
- Exportación del informe a CSV.
- Historial de auditoría de cambios sobre precios y reservas.

---

## Autor

**Maria Olivero** — Prueba técnica para Desarrollador Junior.
