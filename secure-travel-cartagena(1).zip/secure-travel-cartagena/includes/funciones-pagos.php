<?php
/**
 * Pasarela de pagos simulada.
 *
 * Reproduce el flujo de una pasarela real (validacion de la tarjeta,
 * respuesta de la entidad, referencia de transaccion y registro del
 * pago asociado a la reserva) sin realizar ninguna conexion externa.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Regla de simulacion:
 *   - Toda tarjeta valida de 16 digitos es APROBADA.
 *   - Las tarjetas terminadas en 0000 son RECHAZADAS, para poder
 *     probar el manejo de errores del sistema.
 */
define( 'STC_TARJETA_RECHAZO', '0000' );

/**
 * Total ya pagado de una reserva.
 */
function stc_total_pagado( $reserva_id ) {
    global $wpdb;
    $tabla = stc_tabla( 'pagos' );
    $total = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT SUM(monto) FROM $tabla WHERE reserva_id = %d AND estado = 'aprobado'",
            (int) $reserva_id
        )
    );
    return (float) $total;
}

/**
 * Saldo pendiente de una reserva.
 */
function stc_saldo_pendiente( $reserva_id ) {
    $reserva = stc_obtener_reserva( $reserva_id );
    if ( ! $reserva ) {
        return 0;
    }
    $saldo = (float) $reserva->total - stc_total_pagado( $reserva_id );
    return $saldo > 0 ? $saldo : 0;
}

/**
 * Pagos registrados para una reserva.
 */
function stc_pagos_de_reserva( $reserva_id ) {
    global $wpdb;
    $tabla = stc_tabla( 'pagos' );
    return $wpdb->get_results(
        $wpdb->prepare( "SELECT * FROM $tabla WHERE reserva_id = %d ORDER BY fecha_pago DESC", (int) $reserva_id )
    );
}

/**
 * Procesa un pago simulado y lo asocia a la reserva.
 *
 * @return array ['exito' => bool, 'mensaje' => string, 'referencia' => string]
 */
function stc_procesar_pago( $reserva_id, $datos ) {
    global $wpdb;

    $reserva_id = (int) $reserva_id;
    $reserva    = stc_obtener_reserva( $reserva_id );

    if ( ! $reserva ) {
        return array( 'exito' => false, 'mensaje' => 'La reserva indicada no existe.' );
    }

    // --- Sanitizacion ---
    $titular = sanitize_text_field( $datos['titular'] );
    $tarjeta = preg_replace( '/[^0-9]/', '', $datos['numero_tarjeta'] );
    $cvv     = preg_replace( '/[^0-9]/', '', $datos['cvv'] );
    $vence   = sanitize_text_field( $datos['vencimiento'] );
    $monto   = (float) $datos['monto'];

    // --- Validacion de los datos de la tarjeta ---
    if ( '' === $titular ) {
        return array( 'exito' => false, 'mensaje' => 'El nombre del titular es obligatorio.' );
    }
    if ( 16 !== strlen( $tarjeta ) ) {
        return array( 'exito' => false, 'mensaje' => 'El numero de tarjeta debe tener 16 digitos.' );
    }
    if ( strlen( $cvv ) < 3 || strlen( $cvv ) > 4 ) {
        return array( 'exito' => false, 'mensaje' => 'El codigo de seguridad (CVV) debe tener 3 o 4 digitos.' );
    }
    if ( ! preg_match( '/^(0[1-9]|1[0-2])\/[0-9]{2}$/', $vence ) ) {
        return array( 'exito' => false, 'mensaje' => 'La fecha de vencimiento debe tener el formato MM/AA.' );
    }

    // --- Validacion del monto ---
    $saldo = stc_saldo_pendiente( $reserva_id );

    if ( $saldo <= 0 ) {
        return array( 'exito' => false, 'mensaje' => 'Esta reserva ya se encuentra pagada en su totalidad.' );
    }
    if ( $monto <= 0 ) {
        return array( 'exito' => false, 'mensaje' => 'El monto a pagar debe ser mayor a cero.' );
    }
    if ( $monto > $saldo ) {
        return array(
            'exito'   => false,
            'mensaje' => 'El monto excede el saldo pendiente de ' . stc_precio( $saldo ) . '.',
        );
    }

    // --- Simulacion de la respuesta de la entidad financiera ---
    $aprobado = ( substr( $tarjeta, -4 ) !== STC_TARJETA_RECHAZO );

    if ( ! $aprobado ) {
        return array(
            'exito'   => false,
            'mensaje' => 'Pago RECHAZADO por la entidad financiera. Verifica los datos de la tarjeta o intenta con otro medio de pago.',
        );
    }

    // --- Registro del pago, asociado a la reserva ---
    $referencia = 'STC-' . date( 'Ymd' ) . '-' . strtoupper( wp_generate_password( 6, false, false ) );

    $wpdb->insert(
        stc_tabla( 'pagos' ),
        array(
            'reserva_id'      => $reserva_id,
            'monto'           => $monto,
            'metodo'          => 'tarjeta',
            'titular'         => $titular,
            'ultimos_digitos' => substr( $tarjeta, -4 ),
            'referencia'      => $referencia,
            'estado'          => 'aprobado',
            'registrado_por'  => get_current_user_id(),
            'fecha_pago'      => current_time( 'mysql' ),
        ),
        array( '%d', '%f', '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
    );

    // --- Actualizacion del estado de la reserva ---
    // Si con este pago se cubre el total, la reserva queda pagada;
    // si no, queda como abonada (pago parcial).
    $nuevo_saldo  = stc_saldo_pendiente( $reserva_id );
    $nuevo_estado = ( $nuevo_saldo <= 0 ) ? 'pagada' : 'abonada';

    $wpdb->update(
        stc_tabla( 'reservas' ),
        array( 'estado' => $nuevo_estado ),
        array( 'id' => $reserva_id ),
        array( '%s' ),
        array( '%d' )
    );

    $mensaje = 'Pago APROBADO por ' . stc_precio( $monto ) . '. Referencia: ' . $referencia . '.';
    if ( $nuevo_saldo > 0 ) {
        $mensaje .= ' Saldo pendiente: ' . stc_precio( $nuevo_saldo ) . '.';
    }

    return array(
        'exito'      => true,
        'referencia' => $referencia,
        'mensaje'    => $mensaje,
    );
}
