<?php
/**
 * Instalacion del plugin: creacion de tablas, roles y datos iniciales.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Se ejecuta al activar el plugin.
 */
function stc_activar_plugin() {
    stc_crear_tablas();
    stc_crear_roles();
    stc_insertar_datos_demo();
}

/**
 * Se ejecuta al desactivar el plugin.
 * Se eliminan los roles, pero NO las tablas: los datos de reservas
 * y pagos deben conservarse aunque el plugin se desactive.
 */
function stc_desactivar_plugin() {
    remove_role( 'stc_administrador' );
    remove_role( 'stc_recepcionista' );
}

/**
 * Nombres de las tablas del plugin.
 */
function stc_tabla( $nombre ) {
    global $wpdb;
    return $wpdb->prefix . 'stc_' . $nombre;
}

/* ==================================================================
 * MODELO DE DATOS
 * ==================================================================
 * habitaciones          -> inventario del hotel
 * reservas              -> cabecera de la reserva (cliente, fechas, totales)
 * reserva_habitaciones  -> detalle: que habitaciones incluye cada reserva
 * pagos                 -> pagos registrados y asociados a una reserva
 *
 * Se usa una tabla de detalle porque una reserva puede incluir varias
 * habitaciones. Guardar el listado en un solo campo impediria validar
 * la disponibilidad habitacion por habitacion.
 */

function stc_crear_tablas() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $t_habitaciones = stc_tabla( 'habitaciones' );
    $t_reservas     = stc_tabla( 'reservas' );
    $t_detalle      = stc_tabla( 'reserva_habitaciones' );
    $t_pagos        = stc_tabla( 'pagos' );

    $sql_habitaciones = "CREATE TABLE $t_habitaciones (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        numero VARCHAR(10) NOT NULL,
        tipo VARCHAR(20) NOT NULL,
        capacidad INT(11) NOT NULL DEFAULT 2,
        precio_noche DECIMAL(12,2) NOT NULL DEFAULT 0,
        descripcion TEXT NULL,
        activa TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY numero (numero),
        KEY tipo (tipo)
    ) $charset;";

    $sql_reservas = "CREATE TABLE $t_reservas (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        cliente_nombre VARCHAR(150) NOT NULL,
        cliente_documento VARCHAR(50) NOT NULL,
        cliente_tipo VARCHAR(20) NOT NULL DEFAULT 'esporadico',
        cliente_email VARCHAR(150) NULL,
        cliente_telefono VARCHAR(50) NULL,
        fecha_llegada DATE NOT NULL,
        fecha_salida DATE NOT NULL,
        num_huespedes INT(11) NOT NULL DEFAULT 1,
        num_habitaciones INT(11) NOT NULL DEFAULT 1,
        subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
        descuento DECIMAL(12,2) NOT NULL DEFAULT 0,
        total DECIMAL(12,2) NOT NULL DEFAULT 0,
        estado VARCHAR(20) NOT NULL DEFAULT 'pendiente',
        creada_por BIGINT(20) UNSIGNED NULL,
        creada_en DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY documento (cliente_documento),
        KEY fechas (fecha_llegada, fecha_salida)
    ) $charset;";

    $sql_detalle = "CREATE TABLE $t_detalle (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reserva_id BIGINT(20) UNSIGNED NOT NULL,
        habitacion_id BIGINT(20) UNSIGNED NOT NULL,
        precio_noche DECIMAL(12,2) NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        KEY reserva_id (reserva_id),
        KEY habitacion_id (habitacion_id)
    ) $charset;";

    $sql_pagos = "CREATE TABLE $t_pagos (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        reserva_id BIGINT(20) UNSIGNED NOT NULL,
        monto DECIMAL(12,2) NOT NULL DEFAULT 0,
        metodo VARCHAR(30) NOT NULL DEFAULT 'tarjeta',
        titular VARCHAR(150) NULL,
        ultimos_digitos VARCHAR(4) NULL,
        referencia VARCHAR(60) NOT NULL,
        estado VARCHAR(20) NOT NULL DEFAULT 'aprobado',
        registrado_por BIGINT(20) UNSIGNED NULL,
        fecha_pago DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY reserva_id (reserva_id),
        UNIQUE KEY referencia (referencia)
    ) $charset;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql_habitaciones );
    dbDelta( $sql_reservas );
    dbDelta( $sql_detalle );
    dbDelta( $sql_pagos );
}

/* ==================================================================
 * ROLES Y CAPACIDADES
 * ==================================================================
 * Cada requerimiento funcional del enunciado se traduce en una
 * capacidad propia. Asi el control de acceso queda explicito y se
 * puede verificar con current_user_can() en cada accion.
 */

function stc_capacidades_recepcionista() {
    return array(
        'read'                      => true,
        'stc_consultar_disponibilidad' => true, // Requerimiento 1
        'stc_calcular_precio'       => true,    // Requerimiento 2
        'stc_registrar_reservas'    => true,    // Requerimiento 3
        'stc_eliminar_reservas'     => true,    // Requerimiento 4
        'stc_ver_reservas'          => true,
        'stc_registrar_pagos'       => true,    // Pasarela de pagos
    );
}

function stc_capacidades_administrador() {
    // El administrador hereda todo lo de recepcion y suma
    // la gestion de habitaciones y los informes.
    return array_merge(
        stc_capacidades_recepcionista(),
        array(
            'stc_gestionar_habitaciones' => true, // CRUD habitaciones
            'stc_ver_informes'           => true, // Informe de ocupacion
        )
    );
}

function stc_crear_roles() {

    add_role( 'stc_recepcionista', 'Recepcionista', stc_capacidades_recepcionista() );
    add_role( 'stc_administrador', 'Administrador de Hotel', stc_capacidades_administrador() );

    // El administrador nativo de WordPress recibe todas las
    // capacidades para facilitar la revision del sistema.
    $admin_wp = get_role( 'administrator' );
    if ( $admin_wp ) {
        foreach ( array_keys( stc_capacidades_administrador() ) as $cap ) {
            if ( 'read' !== $cap ) {
                $admin_wp->add_cap( $cap );
            }
        }
    }
}

/* ==================================================================
 * DATOS DE EJEMPLO
 * ==================================================================
 * Se cargan al activar para que el sistema sea funcional de
 * inmediato, sin configuracion manual previa.
 */

function stc_insertar_datos_demo() {
    global $wpdb;
    $tabla = stc_tabla( 'habitaciones' );

    if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tabla" ) > 0 ) {
        return; // Ya hay inventario cargado.
    }

    // Tipos definidos en el enunciado: Sencilla, Doble y Familiar.
    $habitaciones = array(
        array( '101', 'Sencilla', 1, 180000, 'Habitacion sencilla, cama individual, vista interior.' ),
        array( '102', 'Sencilla', 1, 180000, 'Habitacion sencilla, cama individual.' ),
        array( '103', 'Doble',    2, 260000, 'Habitacion doble con balcon.' ),
        array( '201', 'Doble',    2, 260000, 'Habitacion doble, piso 2.' ),
        array( '202', 'Doble',    2, 280000, 'Habitacion doble con vista al mar.' ),
        array( '301', 'Familiar', 4, 420000, 'Habitacion familiar, dos camas dobles.' ),
        array( '302', 'Familiar', 5, 480000, 'Habitacion familiar amplia con vista al mar Caribe.' ),
    );

    foreach ( $habitaciones as $h ) {
        $wpdb->insert(
            $tabla,
            array(
                'numero'       => $h[0],
                'tipo'         => $h[1],
                'capacidad'    => $h[2],
                'precio_noche' => $h[3],
                'descripcion'  => $h[4],
                'activa'       => 1,
            ),
            array( '%s', '%s', '%d', '%f', '%s', '%d' )
        );
    }
}
