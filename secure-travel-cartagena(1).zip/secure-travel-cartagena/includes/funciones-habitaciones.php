<?php
/**
 * Logica de negocio de habitaciones (CRUD).
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Tipos de habitacion permitidos, segun el enunciado.
 */
function stc_tipos_habitacion() {
    return array( 'Sencilla', 'Doble', 'Familiar' );
}

/**
 * Lista habitaciones. Si $solo_activas es true, omite las inactivas.
 */
function stc_listar_habitaciones( $solo_activas = false ) {
    global $wpdb;
    $tabla = stc_tabla( 'habitaciones' );
    $where = $solo_activas ? 'WHERE activa = 1' : '';
    return $wpdb->get_results( "SELECT * FROM $tabla $where ORDER BY numero ASC" );
}

/**
 * Obtiene una habitacion por su ID.
 */
function stc_obtener_habitacion( $id ) {
    global $wpdb;
    $tabla = stc_tabla( 'habitaciones' );
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $tabla WHERE id = %d", (int) $id ) );
}

/**
 * Obtiene una habitacion por su numero.
 */
function stc_obtener_habitacion_por_numero( $numero ) {
    global $wpdb;
    $tabla = stc_tabla( 'habitaciones' );
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $tabla WHERE numero = %s", $numero ) );
}

/**
 * CREATE / UPDATE de habitaciones.
 *
 * @return array ['exito' => bool, 'mensaje' => string]
 */
function stc_guardar_habitacion( $datos, $id = 0 ) {
    global $wpdb;
    $tabla = stc_tabla( 'habitaciones' );

    $numero      = sanitize_text_field( $datos['numero'] );
    $tipo        = sanitize_text_field( $datos['tipo'] );
    $capacidad   = (int) $datos['capacidad'];
    $precio      = (float) $datos['precio_noche'];
    $descripcion = sanitize_textarea_field( $datos['descripcion'] );
    $activa      = ! empty( $datos['activa'] ) ? 1 : 0;

    // --- Validaciones ---
    if ( '' === $numero ) {
        return array( 'exito' => false, 'mensaje' => 'El numero de habitacion es obligatorio.' );
    }
    if ( ! in_array( $tipo, stc_tipos_habitacion(), true ) ) {
        return array( 'exito' => false, 'mensaje' => 'El tipo de habitacion no es valido.' );
    }
    if ( $capacidad < 1 ) {
        return array( 'exito' => false, 'mensaje' => 'La capacidad debe ser de al menos 1 huesped.' );
    }
    if ( $precio <= 0 ) {
        return array( 'exito' => false, 'mensaje' => 'El precio por noche debe ser mayor a cero.' );
    }

    // El numero de habitacion no se puede repetir.
    $duplicada = $wpdb->get_var(
        $wpdb->prepare( "SELECT id FROM $tabla WHERE numero = %s AND id != %d", $numero, (int) $id )
    );
    if ( $duplicada ) {
        return array( 'exito' => false, 'mensaje' => 'Ya existe una habitacion con el numero ' . $numero . '.' );
    }

    $valores = array(
        'numero'       => $numero,
        'tipo'         => $tipo,
        'capacidad'    => $capacidad,
        'precio_noche' => $precio,
        'descripcion'  => $descripcion,
        'activa'       => $activa,
    );
    $formatos = array( '%s', '%s', '%d', '%f', '%s', '%d' );

    if ( $id > 0 ) {
        $wpdb->update( $tabla, $valores, array( 'id' => (int) $id ), $formatos, array( '%d' ) );
        return array( 'exito' => true, 'mensaje' => 'Habitacion ' . $numero . ' actualizada correctamente.' );
    }

    $wpdb->insert( $tabla, $valores, $formatos );
    return array( 'exito' => true, 'mensaje' => 'Habitacion ' . $numero . ' creada correctamente.' );
}

/**
 * DELETE de habitaciones.
 * No se permite eliminar una habitacion que ya tiene reservas
 * asociadas, para no dejar registros historicos inconsistentes.
 * En ese caso se sugiere desactivarla.
 */
function stc_eliminar_habitacion( $id ) {
    global $wpdb;
    $t_hab     = stc_tabla( 'habitaciones' );
    $t_detalle = stc_tabla( 'reserva_habitaciones' );

    $id = (int) $id;

    $reservas = (int) $wpdb->get_var(
        $wpdb->prepare( "SELECT COUNT(*) FROM $t_detalle WHERE habitacion_id = %d", $id )
    );

    if ( $reservas > 0 ) {
        return array(
            'exito'   => false,
            'mensaje' => 'No se puede eliminar: la habitacion tiene ' . $reservas . ' reserva(s) asociada(s). Puedes desactivarla para retirarla del inventario disponible.',
        );
    }

    $wpdb->delete( $t_hab, array( 'id' => $id ), array( '%d' ) );
    return array( 'exito' => true, 'mensaje' => 'Habitacion eliminada correctamente.' );
}

/**
 * Formatea un valor como precio en pesos colombianos.
 */
function stc_precio( $valor ) {
    return '$' . number_format( (float) $valor, 0, ',', '.' );
}
