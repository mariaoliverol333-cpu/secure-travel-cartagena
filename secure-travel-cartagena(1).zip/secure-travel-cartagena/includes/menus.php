<?php
/**
 * Menus del panel de administracion.
 *
 * Cada pagina se registra con la capacidad que exige el
 * requerimiento correspondiente, de modo que WordPress oculta el
 * menu a quien no tenga permiso. Ademas, cada vista vuelve a
 * verificar el permiso antes de ejecutar cualquier accion.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'admin_menu', 'stc_registrar_menus' );
function stc_registrar_menus() {

    // Menu principal.
    add_menu_page(
        'Secure Travel Cartagena',
        'Secure Travel',
        'stc_ver_reservas',
        'stc-reservas',
        'stc_vista_reservas',
        'dashicons-building',
        26
    );

    add_submenu_page(
        'stc-reservas',
        'Reservas',
        'Reservas',
        'stc_ver_reservas',
        'stc-reservas',
        'stc_vista_reservas'
    );

    // --- RECEPCIONISTA ---

    add_submenu_page(
        'stc-reservas',
        'Consultar disponibilidad',
        'Disponibilidad',
        'stc_consultar_disponibilidad',
        'stc-disponibilidad',
        'stc_vista_disponibilidad'
    );

    add_submenu_page(
        'stc-reservas',
        'Nueva reserva',
        'Nueva reserva',
        'stc_registrar_reservas',
        'stc-nueva-reserva',
        'stc_vista_nueva_reserva'
    );

    add_submenu_page(
        'stc-reservas',
        'Eliminar reserva',
        'Eliminar reserva',
        'stc_eliminar_reservas',
        'stc-eliminar-reserva',
        'stc_vista_eliminar_reserva'
    );

    // --- ADMINISTRADOR ---

    add_submenu_page(
        'stc-reservas',
        'Habitaciones',
        'Habitaciones',
        'stc_gestionar_habitaciones',
        'stc-habitaciones',
        'stc_vista_habitaciones'
    );

    add_submenu_page(
        'stc-reservas',
        'Informe de ocupacion',
        'Informes',
        'stc_ver_informes',
        'stc-informe',
        'stc_vista_informe'
    );

    // --- PASARELA DE PAGOS ---
    // Pagina oculta del menu: se accede desde una reserva concreta.
    add_submenu_page(
        null,
        'Registrar pago',
        'Registrar pago',
        'stc_registrar_pagos',
        'stc-pago',
        'stc_vista_pago'
    );
}

/* ------------------------------------------------------------------
 * Carga de las vistas
 * ------------------------------------------------------------------ */

function stc_vista_reservas() {
    require STC_PATH . 'admin/vista-reservas.php';
}

function stc_vista_disponibilidad() {
    require STC_PATH . 'admin/vista-disponibilidad.php';
}

function stc_vista_nueva_reserva() {
    require STC_PATH . 'admin/vista-nueva-reserva.php';
}

function stc_vista_eliminar_reserva() {
    require STC_PATH . 'admin/vista-eliminar-reserva.php';
}

function stc_vista_habitaciones() {
    require STC_PATH . 'admin/vista-habitaciones.php';
}

function stc_vista_informe() {
    require STC_PATH . 'admin/vista-informe.php';
}

function stc_vista_pago() {
    require STC_PATH . 'admin/vista-pago.php';
}

/* ------------------------------------------------------------------
 * Utilidades para las vistas
 * ------------------------------------------------------------------ */

/**
 * Muestra un aviso en el panel.
 */
function stc_aviso( $mensaje, $tipo = 'success' ) {
    printf(
        '<div class="notice notice-%s"><p>%s</p></div>',
        esc_attr( $tipo ),
        esc_html( $mensaje )
    );
}

/**
 * Etiqueta de color segun el estado de la reserva.
 */
function stc_etiqueta_estado( $estado ) {
    $clases = array(
        'pendiente' => 'stc-badge stc-badge-pendiente',
        'abonada'   => 'stc-badge stc-badge-abonada',
        'pagada'    => 'stc-badge stc-badge-pagada',
    );
    $clase = isset( $clases[ $estado ] ) ? $clases[ $estado ] : 'stc-badge';
    return '<span class="' . esc_attr( $clase ) . '">' . esc_html( ucfirst( $estado ) ) . '</span>';
}

/**
 * Corta la ejecucion si el usuario no tiene la capacidad indicada.
 */
function stc_exigir_permiso( $capacidad ) {
    if ( ! current_user_can( $capacidad ) ) {
        wp_die( 'No tienes permisos suficientes para acceder a esta seccion.' );
    }
}
