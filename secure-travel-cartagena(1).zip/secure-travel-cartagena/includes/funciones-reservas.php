<?php
/**
 * Logica de negocio de reservas: disponibilidad, precios,
 * registro y eliminacion.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Tipos de cliente definidos en el enunciado.
 */
function stc_tipos_cliente() {
    return array(
        'frecuente'  => 'Frecuente',
        'esporadico' => 'Esporadico',
    );
}

/**
 * Numero de noches entre dos fechas.
 */
function stc_calcular_noches( $llegada, $salida ) {
    $d1 = new DateTime( $llegada );
    $d2 = new DateTime( $salida );
    return (int) $d1->diff( $d2 )->days;
}

/* ==================================================================
 * DISPONIBILIDAD
 * ==================================================================
 * Dos estadias se cruzan cuando:
 *
 *     llegada_existente < salida_nueva  Y  salida_existente > llegada_nueva
 *
 * Se usan comparaciones estrictas (< y >) de forma intencional: si un
 * huesped sale el mismo dia que otro llega, la habitacion SI esta
 * disponible, tal como funciona la operacion real de un hotel.
 */

/**
 * Devuelve las habitaciones libres en un rango de fechas.
 *
 * @param string $llegada            Fecha Y-m-d.
 * @param string $salida             Fecha Y-m-d.
 * @param int    $excluir_reserva_id Reserva a ignorar (util al editar).
 */
function stc_habitaciones_disponibles( $llegada, $salida, $excluir_reserva_id = 0 ) {
    global $wpdb;
    $t_hab     = stc_tabla( 'habitaciones' );
    $t_res     = stc_tabla( 'reservas' );
    $t_detalle = stc_tabla( 'reserva_habitaciones' );

    $excluir_reserva_id = (int) $excluir_reserva_id;
    $filtro_excluir     = $excluir_reserva_id > 0 ? 'AND r.id != %d' : '';

    $sql = "SELECT h.* FROM $t_hab h
            WHERE h.activa = 1
              AND h.id NOT IN (
                  SELECT d.habitacion_id
                  FROM $t_detalle d
                  INNER JOIN $t_res r ON r.id = d.reserva_id
                  WHERE r.fecha_llegada < %s
                    AND r.fecha_salida  > %s
                    $filtro_excluir
              )
            ORDER BY h.tipo ASC, h.numero ASC";

    $params = array( $salida, $llegada );
    if ( $excluir_reserva_id > 0 ) {
        $params[] = $excluir_reserva_id;
    }

    return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
}

/**
 * Devuelve las habitaciones ocupadas en un rango de fechas,
 * junto con la reserva que las ocupa. Usado en el informe.
 */
function stc_habitaciones_ocupadas( $llegada, $salida ) {
    global $wpdb;
    $t_hab     = stc_tabla( 'habitaciones' );
    $t_res     = stc_tabla( 'reservas' );
    $t_detalle = stc_tabla( 'reserva_habitaciones' );

    $sql = "SELECT h.*, r.id AS reserva_id, r.cliente_nombre, r.cliente_tipo,
                   r.fecha_llegada, r.fecha_salida, r.estado
            FROM $t_detalle d
            INNER JOIN $t_hab h ON h.id = d.habitacion_id
            INNER JOIN $t_res r ON r.id = d.reserva_id
            WHERE r.fecha_llegada < %s
              AND r.fecha_salida  > %s
            ORDER BY h.numero ASC";

    return $wpdb->get_results( $wpdb->prepare( $sql, $salida, $llegada ) );
}

/**
 * Verifica si una habitacion concreta esta libre en un rango.
 */
function stc_habitacion_esta_disponible( $habitacion_id, $llegada, $salida, $excluir_reserva_id = 0 ) {
    $disponibles = stc_habitaciones_disponibles( $llegada, $salida, $excluir_reserva_id );
    foreach ( $disponibles as $h ) {
        if ( (int) $h->id === (int) $habitacion_id ) {
            return true;
        }
    }
    return false;
}

/* ==================================================================
 * CALCULO DE PRECIO
 * ==================================================================
 * Requerimiento del recepcionista: "Calcular el precio total para
 * un cliente".
 *
 *   subtotal  = suma(precio_noche de cada habitacion) x numero de noches
 *   descuento = subtotal x porcentaje segun el tipo de cliente
 *   total     = subtotal - descuento
 *
 * Los clientes FRECUENTES reciben un descuento definido en la
 * constante STC_DESCUENTO_FRECUENTE. Los ESPORADICOS pagan tarifa plena.
 */

function stc_calcular_precio( $habitacion_ids, $llegada, $salida, $tipo_cliente ) {

    $noches   = stc_calcular_noches( $llegada, $salida );
    $subtotal = 0;
    $detalle  = array();

    foreach ( (array) $habitacion_ids as $id ) {
        $habitacion = stc_obtener_habitacion( $id );
        if ( ! $habitacion ) {
            continue;
        }
        $importe   = (float) $habitacion->precio_noche * $noches;
        $subtotal += $importe;

        $detalle[] = array(
            'habitacion'   => $habitacion,
            'precio_noche' => (float) $habitacion->precio_noche,
            'importe'      => $importe,
        );
    }

    $porcentaje = ( 'frecuente' === $tipo_cliente ) ? (float) STC_DESCUENTO_FRECUENTE : 0;
    $descuento  = $subtotal * $porcentaje / 100;

    return array(
        'noches'      => $noches,
        'detalle'     => $detalle,
        'subtotal'    => $subtotal,
        'porcentaje'  => $porcentaje,
        'descuento'   => $descuento,
        'total'       => $subtotal - $descuento,
    );
}

/* ==================================================================
 * REGISTRO DE RESERVAS
 * ================================================================== */

/**
 * Registra una reserva con una o varias habitaciones.
 *
 * @return array ['exito' => bool, 'mensaje' => string, 'reserva_id' => int]
 */
function stc_registrar_reserva( $datos ) {
    global $wpdb;

    $t_res     = stc_tabla( 'reservas' );
    $t_detalle = stc_tabla( 'reserva_habitaciones' );

    // --- Sanitizacion de entradas ---
    $nombre     = sanitize_text_field( $datos['cliente_nombre'] );
    $documento  = sanitize_text_field( $datos['cliente_documento'] );
    $tipo       = sanitize_text_field( $datos['cliente_tipo'] );
    $email      = isset( $datos['cliente_email'] ) ? sanitize_email( $datos['cliente_email'] ) : '';
    $telefono   = isset( $datos['cliente_telefono'] ) ? sanitize_text_field( $datos['cliente_telefono'] ) : '';
    $llegada    = sanitize_text_field( $datos['fecha_llegada'] );
    $salida     = sanitize_text_field( $datos['fecha_salida'] );
    $huespedes  = (int) $datos['num_huespedes'];
    $hab_ids    = array_map( 'intval', (array) $datos['habitaciones'] );

    // --- Validaciones ---
    if ( '' === $nombre ) {
        return array( 'exito' => false, 'mensaje' => 'El nombre del cliente es obligatorio.' );
    }
    if ( '' === $documento ) {
        return array( 'exito' => false, 'mensaje' => 'El documento del cliente es obligatorio.' );
    }
    if ( ! array_key_exists( $tipo, stc_tipos_cliente() ) ) {
        return array( 'exito' => false, 'mensaje' => 'El tipo de cliente no es valido.' );
    }
    if ( '' !== $email && ! is_email( $email ) ) {
        return array( 'exito' => false, 'mensaje' => 'El correo electronico no tiene un formato valido.' );
    }
    if ( '' === $llegada || '' === $salida ) {
        return array( 'exito' => false, 'mensaje' => 'Las fechas de llegada y salida son obligatorias.' );
    }
    if ( strtotime( $salida ) <= strtotime( $llegada ) ) {
        return array( 'exito' => false, 'mensaje' => 'La fecha de salida debe ser posterior a la de llegada.' );
    }
    if ( strtotime( $llegada ) < strtotime( date( 'Y-m-d' ) ) ) {
        return array( 'exito' => false, 'mensaje' => 'La fecha de llegada no puede estar en el pasado.' );
    }
    if ( empty( $hab_ids ) ) {
        return array( 'exito' => false, 'mensaje' => 'Debes seleccionar al menos una habitacion.' );
    }
    if ( $huespedes < 1 ) {
        return array( 'exito' => false, 'mensaje' => 'La cantidad de huespedes debe ser al menos 1.' );
    }

    // --- Validacion de disponibilidad y capacidad ---
    $capacidad_total = 0;
    foreach ( $hab_ids as $id ) {
        $habitacion = stc_obtener_habitacion( $id );
        if ( ! $habitacion ) {
            return array( 'exito' => false, 'mensaje' => 'Una de las habitaciones seleccionadas no existe.' );
        }
        if ( ! stc_habitacion_esta_disponible( $id, $llegada, $salida ) ) {
            return array(
                'exito'   => false,
                'mensaje' => 'La habitacion ' . $habitacion->numero . ' ya no esta disponible en esas fechas. Vuelve a consultar la disponibilidad.',
            );
        }
        $capacidad_total += (int) $habitacion->capacidad;
    }

    if ( $huespedes > $capacidad_total ) {
        return array(
            'exito'   => false,
            'mensaje' => 'Las habitaciones seleccionadas admiten maximo ' . $capacidad_total . ' huespedes y se solicitaron ' . $huespedes . '. Selecciona una habitacion adicional.',
        );
    }

    // --- Calculo del precio ---
    $precio = stc_calcular_precio( $hab_ids, $llegada, $salida, $tipo );

    // --- Insercion de la cabecera ---
    $wpdb->insert(
        $t_res,
        array(
            'cliente_nombre'    => $nombre,
            'cliente_documento' => $documento,
            'cliente_tipo'      => $tipo,
            'cliente_email'     => $email,
            'cliente_telefono'  => $telefono,
            'fecha_llegada'     => $llegada,
            'fecha_salida'      => $salida,
            'num_huespedes'     => $huespedes,
            'num_habitaciones'  => count( $hab_ids ),
            'subtotal'          => $precio['subtotal'],
            'descuento'         => $precio['descuento'],
            'total'             => $precio['total'],
            'estado'            => 'pendiente',
            'creada_por'        => get_current_user_id(),
            'creada_en'         => current_time( 'mysql' ),
        ),
        array( '%s','%s','%s','%s','%s','%s','%s','%d','%d','%f','%f','%f','%s','%d','%s' )
    );

    $reserva_id = (int) $wpdb->insert_id;

    if ( ! $reserva_id ) {
        return array( 'exito' => false, 'mensaje' => 'No fue posible registrar la reserva. Intenta nuevamente.' );
    }

    // --- Insercion del detalle de habitaciones ---
    // Se guarda el precio vigente al momento de reservar, para que un
    // cambio de tarifa posterior no altere reservas ya registradas.
    foreach ( $precio['detalle'] as $linea ) {
        $wpdb->insert(
            $t_detalle,
            array(
                'reserva_id'    => $reserva_id,
                'habitacion_id' => $linea['habitacion']->id,
                'precio_noche'  => $linea['precio_noche'],
            ),
            array( '%d', '%d', '%f' )
        );
    }

    return array(
        'exito'      => true,
        'reserva_id' => $reserva_id,
        'mensaje'    => 'Reserva #' . $reserva_id . ' registrada correctamente por ' . stc_precio( $precio['total'] ) . ' (' . $precio['noches'] . ' noches, ' . count( $hab_ids ) . ' habitacion(es)).',
    );
}

/* ==================================================================
 * CONSULTA DE RESERVAS
 * ================================================================== */

function stc_obtener_reserva( $id ) {
    global $wpdb;
    $tabla = stc_tabla( 'reservas' );
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $tabla WHERE id = %d", (int) $id ) );
}

function stc_listar_reservas() {
    global $wpdb;
    $tabla = stc_tabla( 'reservas' );
    return $wpdb->get_results( "SELECT * FROM $tabla ORDER BY creada_en DESC" );
}

/**
 * Habitaciones incluidas en una reserva.
 */
function stc_habitaciones_de_reserva( $reserva_id ) {
    global $wpdb;
    $t_hab     = stc_tabla( 'habitaciones' );
    $t_detalle = stc_tabla( 'reserva_habitaciones' );

    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT h.*, d.precio_noche AS precio_reservado
             FROM $t_detalle d
             INNER JOIN $t_hab h ON h.id = d.habitacion_id
             WHERE d.reserva_id = %d
             ORDER BY h.numero ASC",
            (int) $reserva_id
        )
    );
}

/**
 * Texto resumido de las habitaciones de una reserva (ej: "101 - Sencilla, 202 - Doble").
 */
function stc_resumen_habitaciones( $reserva_id ) {
    $habitaciones = stc_habitaciones_de_reserva( $reserva_id );
    $partes       = array();
    foreach ( $habitaciones as $h ) {
        $partes[] = $h->numero . ' - ' . $h->tipo;
    }
    return $partes ? implode( ', ', $partes ) : '(sin habitaciones)';
}

/* ==================================================================
 * ELIMINACION DE RESERVAS
 * ==================================================================
 * Requerimiento del recepcionista: "Eliminar una reserva indicando
 * el numero de habitacion".
 */

/**
 * Busca las reservas asociadas a un numero de habitacion.
 * Por defecto solo devuelve las vigentes (que no hayan finalizado).
 */
function stc_buscar_reservas_por_habitacion( $numero, $solo_vigentes = true ) {
    global $wpdb;
    $t_hab     = stc_tabla( 'habitaciones' );
    $t_res     = stc_tabla( 'reservas' );
    $t_detalle = stc_tabla( 'reserva_habitaciones' );

    $filtro = $solo_vigentes ? 'AND r.fecha_salida >= CURDATE()' : '';

    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT r.*, h.numero AS habitacion_numero, h.tipo AS habitacion_tipo
             FROM $t_detalle d
             INNER JOIN $t_res r ON r.id = d.reserva_id
             INNER JOIN $t_hab h ON h.id = d.habitacion_id
             WHERE h.numero = %s
             $filtro
             ORDER BY r.fecha_llegada ASC",
            $numero
        )
    );
}

/**
 * Elimina una reserva y todos sus registros asociados
 * (detalle de habitaciones y pagos), liberando las habitaciones.
 */
function stc_eliminar_reserva( $reserva_id ) {
    global $wpdb;

    $reserva_id = (int) $reserva_id;
    $reserva    = stc_obtener_reserva( $reserva_id );

    if ( ! $reserva ) {
        return array( 'exito' => false, 'mensaje' => 'La reserva indicada no existe.' );
    }

    $habitaciones = stc_resumen_habitaciones( $reserva_id );

    // Se eliminan primero los registros dependientes para no dejar
    // filas huerfanas en la base de datos.
    $wpdb->delete( stc_tabla( 'pagos' ), array( 'reserva_id' => $reserva_id ), array( '%d' ) );
    $wpdb->delete( stc_tabla( 'reserva_habitaciones' ), array( 'reserva_id' => $reserva_id ), array( '%d' ) );
    $wpdb->delete( stc_tabla( 'reservas' ), array( 'id' => $reserva_id ), array( '%d' ) );

    return array(
        'exito'   => true,
        'mensaje' => 'Reserva #' . $reserva_id . ' de ' . $reserva->cliente_nombre . ' eliminada. Se liberaron las habitaciones: ' . $habitaciones . '.',
    );
}
