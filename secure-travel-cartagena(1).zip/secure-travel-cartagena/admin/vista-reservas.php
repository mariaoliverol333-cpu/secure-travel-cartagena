<?php
/**
 * Vista: listado de reservas registradas.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

stc_exigir_permiso( 'stc_ver_reservas' );

// --- Eliminacion directa desde el listado ---
if ( isset( $_GET['accion'], $_GET['id'] ) && 'eliminar' === $_GET['accion'] ) {
    $id = (int) $_GET['id'];

    if ( ! current_user_can( 'stc_eliminar_reservas' ) ) {
        stc_aviso( 'No tienes permisos para eliminar reservas.', 'error' );
    } elseif ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'stc_eliminar_' . $id ) ) {
        stc_aviso( 'Verificacion de seguridad fallida.', 'error' );
    } else {
        $resultado = stc_eliminar_reserva( $id );
        stc_aviso( $resultado['mensaje'], $resultado['exito'] ? 'success' : 'error' );
    }
}

$reservas = stc_listar_reservas();
$usuario  = wp_get_current_user();
$roles    = ! empty( $usuario->roles ) ? implode( ', ', $usuario->roles ) : 'sin rol';
?>
<div class="wrap stc-wrap">
    <h1>
        Reservas
        <?php if ( current_user_can( 'stc_registrar_reservas' ) ) : ?>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=stc-nueva-reserva' ) ); ?>" class="page-title-action">Nueva reserva</a>
        <?php endif; ?>
    </h1>

    <p class="description">
        Sesion iniciada como <strong><?php echo esc_html( $usuario->display_name ); ?></strong>
        (rol: <?php echo esc_html( $roles ); ?>).
    </p>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th style="width:50px;">#</th>
                <th>Cliente</th>
                <th>Tipo</th>
                <th>Habitaciones</th>
                <th>Llegada</th>
                <th>Salida</th>
                <th>Huesp.</th>
                <th>Total</th>
                <th>Pagado</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php if ( empty( $reservas ) ) : ?>
            <tr><td colspan="11">Aun no hay reservas registradas.</td></tr>
        <?php else : ?>
            <?php foreach ( $reservas as $r ) : ?>
                <?php
                $pagado = stc_total_pagado( $r->id );
                $saldo  = stc_saldo_pendiente( $r->id );
                ?>
                <tr>
                    <td><strong><?php echo esc_html( $r->id ); ?></strong></td>
                    <td>
                        <strong><?php echo esc_html( $r->cliente_nombre ); ?></strong><br>
                        <small>Doc: <?php echo esc_html( $r->cliente_documento ); ?></small>
                    </td>
                    <td><?php echo esc_html( stc_tipos_cliente()[ $r->cliente_tipo ] ); ?></td>
                    <td><?php echo esc_html( stc_resumen_habitaciones( $r->id ) ); ?></td>
                    <td><?php echo esc_html( $r->fecha_llegada ); ?></td>
                    <td><?php echo esc_html( $r->fecha_salida ); ?></td>
                    <td><?php echo esc_html( $r->num_huespedes ); ?></td>
                    <td>
                        <strong><?php echo esc_html( stc_precio( $r->total ) ); ?></strong>
                        <?php if ( $r->descuento > 0 ) : ?>
                            <br><small>Desc: -<?php echo esc_html( stc_precio( $r->descuento ) ); ?></small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo esc_html( stc_precio( $pagado ) ); ?>
                        <?php if ( $saldo > 0 ) : ?>
                            <br><small>Saldo: <?php echo esc_html( stc_precio( $saldo ) ); ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo wp_kses_post( stc_etiqueta_estado( $r->estado ) ); ?></td>
                    <td>
                        <?php if ( $saldo > 0 && current_user_can( 'stc_registrar_pagos' ) ) : ?>
                            <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=stc-pago&reserva=' . $r->id ) ); ?>">Pagar</a>
                        <?php endif; ?>

                        <?php if ( current_user_can( 'stc_eliminar_reservas' ) ) : ?>
                            <a class="button stc-boton-rojo"
                               onclick="return confirm('Eliminar la reserva #<?php echo (int) $r->id; ?>? Esta accion no se puede deshacer.');"
                               href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=stc-reservas&accion=eliminar&id=' . $r->id ), 'stc_eliminar_' . $r->id ) ); ?>">
                               Eliminar
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
