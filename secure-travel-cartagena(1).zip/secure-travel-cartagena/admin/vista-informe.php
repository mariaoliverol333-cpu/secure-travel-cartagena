<?php
/**
 * Vista: informe de ocupacion.
 * Requerimiento 2 del rol Administrador:
 * "Generar un informe con las habitaciones disponibles y reservadas".
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

stc_exigir_permiso( 'stc_ver_informes' );

$desde = isset( $_GET['desde'] ) ? sanitize_text_field( $_GET['desde'] ) : date( 'Y-m-d' );
$hasta = isset( $_GET['hasta'] ) ? sanitize_text_field( $_GET['hasta'] ) : date( 'Y-m-d', strtotime( '+7 days' ) );

if ( strtotime( $hasta ) <= strtotime( $desde ) ) {
    $hasta = date( 'Y-m-d', strtotime( $desde . ' +1 day' ) );
}

$disponibles = stc_habitaciones_disponibles( $desde, $hasta );
$ocupadas    = stc_habitaciones_ocupadas( $desde, $hasta );
$inventario  = stc_listar_habitaciones();
$total_hab   = count( $inventario );

$ocupacion = $total_hab > 0 ? round( count( $ocupadas ) / $total_hab * 100 ) : 0;

// Ingresos del periodo.
global $wpdb;
$t_res = stc_tabla( 'reservas' );
$t_pag = stc_tabla( 'pagos' );

$facturado = (float) $wpdb->get_var(
    $wpdb->prepare(
        "SELECT SUM(total) FROM $t_res WHERE fecha_llegada < %s AND fecha_salida > %s",
        $hasta,
        $desde
    )
);

$recaudado = (float) $wpdb->get_var(
    $wpdb->prepare(
        "SELECT SUM(p.monto) FROM $t_pag p
         INNER JOIN $t_res r ON r.id = p.reserva_id
         WHERE p.estado = 'aprobado' AND r.fecha_llegada < %s AND r.fecha_salida > %s",
        $hasta,
        $desde
    )
);

// Distribucion por tipo de habitacion.
$por_tipo = array();
foreach ( stc_tipos_habitacion() as $t ) {
    $por_tipo[ $t ] = array( 'total' => 0, 'ocupadas' => 0 );
}
foreach ( $inventario as $h ) {
    if ( isset( $por_tipo[ $h->tipo ] ) ) {
        $por_tipo[ $h->tipo ]['total']++;
    }
}
foreach ( $ocupadas as $o ) {
    if ( isset( $por_tipo[ $o->tipo ] ) ) {
        $por_tipo[ $o->tipo ]['ocupadas']++;
    }
}
?>
<div class="wrap stc-wrap">
    <h1>Informe de ocupacion</h1>
    <p class="description">Estado del inventario de habitaciones en el periodo seleccionado.</p>

    <form method="get" class="stc-caja">
        <input type="hidden" name="page" value="stc-informe">
        <table class="form-table">
            <tr>
                <th><label for="desde">Desde</label></th>
                <td><input type="date" name="desde" id="desde" value="<?php echo esc_attr( $desde ); ?>" required></td>
                <th><label for="hasta">Hasta</label></th>
                <td><input type="date" name="hasta" id="hasta" value="<?php echo esc_attr( $hasta ); ?>" required></td>
                <td><button type="submit" class="button button-primary">Generar informe</button></td>
            </tr>
        </table>
    </form>

    <div class="stc-resumen">
        <div class="stc-tarjeta stc-gris">
            <span class="stc-numero"><?php echo (int) $total_hab; ?></span>
            <span class="stc-etiqueta">Total habitaciones</span>
        </div>
        <div class="stc-tarjeta stc-verde">
            <span class="stc-numero"><?php echo count( $disponibles ); ?></span>
            <span class="stc-etiqueta">Disponibles</span>
        </div>
        <div class="stc-tarjeta stc-rojo">
            <span class="stc-numero"><?php echo count( $ocupadas ); ?></span>
            <span class="stc-etiqueta">Reservadas</span>
        </div>
        <div class="stc-tarjeta stc-azul">
            <span class="stc-numero"><?php echo (int) $ocupacion; ?>%</span>
            <span class="stc-etiqueta">Ocupacion</span>
        </div>
    </div>

    <div class="stc-resumen">
        <div class="stc-tarjeta stc-azul" style="min-width:220px;">
            <span class="stc-numero" style="font-size:22px;"><?php echo esc_html( stc_precio( $facturado ) ); ?></span>
            <span class="stc-etiqueta">Facturado en el periodo</span>
        </div>
        <div class="stc-tarjeta stc-verde" style="min-width:220px;">
            <span class="stc-numero" style="font-size:22px;"><?php echo esc_html( stc_precio( $recaudado ) ); ?></span>
            <span class="stc-etiqueta">Recaudado (pagos aprobados)</span>
        </div>
        <div class="stc-tarjeta stc-gris" style="min-width:220px;">
            <span class="stc-numero" style="font-size:22px;"><?php echo esc_html( stc_precio( $facturado - $recaudado ) ); ?></span>
            <span class="stc-etiqueta">Pendiente por cobrar</span>
        </div>
    </div>

    <h2>Ocupacion por tipo de habitacion</h2>
    <table class="wp-list-table widefat fixed striped" style="max-width:700px;">
        <thead>
            <tr><th>Tipo</th><th>Total</th><th>Reservadas</th><th>Disponibles</th><th>% Ocupacion</th></tr>
        </thead>
        <tbody>
        <?php foreach ( $por_tipo as $tipo => $datos ) : ?>
            <tr>
                <td><strong><?php echo esc_html( $tipo ); ?></strong></td>
                <td><?php echo (int) $datos['total']; ?></td>
                <td><?php echo (int) $datos['ocupadas']; ?></td>
                <td><?php echo (int) ( $datos['total'] - $datos['ocupadas'] ); ?></td>
                <td><?php echo $datos['total'] > 0 ? (int) round( $datos['ocupadas'] / $datos['total'] * 100 ) : 0; ?>%</td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <h2>Habitaciones disponibles</h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr><th>Numero</th><th>Tipo</th><th>Capacidad</th><th>Precio / noche</th><th>Descripcion</th></tr>
        </thead>
        <tbody>
        <?php if ( empty( $disponibles ) ) : ?>
            <tr><td colspan="5">No hay habitaciones disponibles en este periodo.</td></tr>
        <?php else : ?>
            <?php foreach ( $disponibles as $h ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $h->numero ); ?></strong></td>
                    <td><?php echo esc_html( $h->tipo ); ?></td>
                    <td><?php echo esc_html( $h->capacidad ); ?></td>
                    <td><?php echo esc_html( stc_precio( $h->precio_noche ) ); ?></td>
                    <td><?php echo esc_html( $h->descripcion ); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

    <h2>Habitaciones reservadas</h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr><th>Numero</th><th>Tipo</th><th>Reserva</th><th>Cliente</th><th>Tipo cliente</th><th>Llegada</th><th>Salida</th><th>Estado</th></tr>
        </thead>
        <tbody>
        <?php if ( empty( $ocupadas ) ) : ?>
            <tr><td colspan="8">No hay habitaciones reservadas en este periodo.</td></tr>
        <?php else : ?>
            <?php foreach ( $ocupadas as $o ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $o->numero ); ?></strong></td>
                    <td><?php echo esc_html( $o->tipo ); ?></td>
                    <td>#<?php echo esc_html( $o->reserva_id ); ?></td>
                    <td><?php echo esc_html( $o->cliente_nombre ); ?></td>
                    <td><?php echo esc_html( stc_tipos_cliente()[ $o->cliente_tipo ] ); ?></td>
                    <td><?php echo esc_html( $o->fecha_llegada ); ?></td>
                    <td><?php echo esc_html( $o->fecha_salida ); ?></td>
                    <td><?php echo wp_kses_post( stc_etiqueta_estado( $o->estado ) ); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
