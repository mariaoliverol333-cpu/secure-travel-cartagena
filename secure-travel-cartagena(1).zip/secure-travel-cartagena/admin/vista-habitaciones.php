<?php
/**
 * Vista: CRUD de habitaciones.
 * Requerimiento 1 del rol Administrador.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

stc_exigir_permiso( 'stc_gestionar_habitaciones' );

$editando = null;

/* --- CREATE / UPDATE --- */
if ( isset( $_POST['stc_guardar_habitacion'] ) ) {

    if ( ! isset( $_POST['stc_nonce_hab'] ) || ! wp_verify_nonce( $_POST['stc_nonce_hab'], 'stc_guardar_habitacion' ) ) {
        wp_die( 'Verificacion de seguridad fallida.' );
    }

    $id        = isset( $_POST['habitacion_id'] ) ? (int) $_POST['habitacion_id'] : 0;
    $resultado = stc_guardar_habitacion(
        array(
            'numero'       => $_POST['numero'],
            'tipo'         => $_POST['tipo'],
            'capacidad'    => $_POST['capacidad'],
            'precio_noche' => $_POST['precio_noche'],
            'descripcion'  => $_POST['descripcion'],
            'activa'       => isset( $_POST['activa'] ) ? 1 : 0,
        ),
        $id
    );

    stc_aviso( $resultado['mensaje'], $resultado['exito'] ? 'success' : 'error' );

    if ( ! $resultado['exito'] && $id > 0 ) {
        $editando = stc_obtener_habitacion( $id );
    }
}

/* --- DELETE --- */
if ( isset( $_GET['accion'], $_GET['id'] ) && 'eliminar' === $_GET['accion'] ) {
    $id = (int) $_GET['id'];
    if ( isset( $_GET['_wpnonce'] ) && wp_verify_nonce( $_GET['_wpnonce'], 'stc_borrar_hab_' . $id ) ) {
        $resultado = stc_eliminar_habitacion( $id );
        stc_aviso( $resultado['mensaje'], $resultado['exito'] ? 'success' : 'error' );
    }
}

/* --- Cargar habitacion para editar --- */
if ( isset( $_GET['accion'], $_GET['id'] ) && 'editar' === $_GET['accion'] ) {
    $editando = stc_obtener_habitacion( (int) $_GET['id'] );
}

$habitaciones = stc_listar_habitaciones();

// Valores del formulario.
$f_id      = $editando ? (int) $editando->id : 0;
$f_numero  = $editando ? $editando->numero : '';
$f_tipo    = $editando ? $editando->tipo : 'Sencilla';
$f_cap     = $editando ? (int) $editando->capacidad : 2;
$f_precio  = $editando ? (float) $editando->precio_noche : 200000;
$f_desc    = $editando ? $editando->descripcion : '';
$f_activa  = $editando ? (int) $editando->activa : 1;
?>
<div class="wrap stc-wrap">
    <h1>Gestion de habitaciones</h1>
    <p class="description">Alta, consulta, edicion y baja del inventario de habitaciones y sus precios.</p>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Numero</th>
                <th>Tipo</th>
                <th>Capacidad</th>
                <th>Precio / noche</th>
                <th>Descripcion</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php if ( empty( $habitaciones ) ) : ?>
            <tr><td colspan="7">No hay habitaciones registradas.</td></tr>
        <?php else : ?>
            <?php foreach ( $habitaciones as $h ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $h->numero ); ?></strong></td>
                    <td><?php echo esc_html( $h->tipo ); ?></td>
                    <td><?php echo esc_html( $h->capacidad ); ?> huesped(es)</td>
                    <td><?php echo esc_html( stc_precio( $h->precio_noche ) ); ?></td>
                    <td><?php echo esc_html( $h->descripcion ); ?></td>
                    <td>
                        <?php if ( $h->activa ) : ?>
                            <span class="stc-badge stc-badge-pagada">Activa</span>
                        <?php else : ?>
                            <span class="stc-badge stc-badge-pendiente">Inactiva</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=stc-habitaciones&accion=editar&id=' . $h->id ) ); ?>">Editar</a>
                        <a class="button stc-boton-rojo"
                           onclick="return confirm('Eliminar la habitacion <?php echo esc_js( $h->numero ); ?>?');"
                           href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=stc-habitaciones&accion=eliminar&id=' . $h->id ), 'stc_borrar_hab_' . $h->id ) ); ?>">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

    <div class="stc-caja" style="margin-top:25px;">
        <h2><?php echo $editando ? 'Editar habitacion ' . esc_html( $f_numero ) : 'Agregar habitacion'; ?></h2>

        <form method="post">
            <?php wp_nonce_field( 'stc_guardar_habitacion', 'stc_nonce_hab' ); ?>
            <input type="hidden" name="habitacion_id" value="<?php echo esc_attr( $f_id ); ?>">

            <table class="form-table">
                <tr>
                    <th><label for="numero">Numero *</label></th>
                    <td><input type="text" name="numero" id="numero" class="regular-text" value="<?php echo esc_attr( $f_numero ); ?>" required></td>
                </tr>
                <tr>
                    <th><label for="tipo">Tipo *</label></th>
                    <td>
                        <select name="tipo" id="tipo" required>
                            <?php foreach ( stc_tipos_habitacion() as $t ) : ?>
                                <option value="<?php echo esc_attr( $t ); ?>" <?php selected( $f_tipo, $t ); ?>>
                                    <?php echo esc_html( $t ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="capacidad">Capacidad *</label></th>
                    <td><input type="number" name="capacidad" id="capacidad" min="1" max="20" value="<?php echo esc_attr( $f_cap ); ?>" required></td>
                </tr>
                <tr>
                    <th><label for="precio_noche">Precio por noche *</label></th>
                    <td><input type="number" name="precio_noche" id="precio_noche" min="0" step="any" value="<?php echo esc_attr( $f_precio ); ?>" required></td>
                </tr>
                <tr>
                    <th><label for="descripcion">Descripcion</label></th>
                    <td><textarea name="descripcion" id="descripcion" rows="3" class="large-text"><?php echo esc_textarea( $f_desc ); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="activa">Disponible para reservar</label></th>
                    <td>
                        <label>
                            <input type="checkbox" name="activa" id="activa" value="1" <?php checked( $f_activa, 1 ); ?>>
                            Habitacion activa
                        </label>
                    </td>
                </tr>
            </table>

            <?php submit_button( $editando ? 'Actualizar habitacion' : 'Guardar habitacion', 'primary', 'stc_guardar_habitacion' ); ?>

            <?php if ( $editando ) : ?>
                <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=stc-habitaciones' ) ); ?>">Cancelar edicion</a>
            <?php endif; ?>
        </form>
    </div>
</div>
