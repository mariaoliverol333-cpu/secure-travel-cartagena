<?php
/**
 * Vista: consultar listado de habitaciones disponibles.
 * Requerimiento 1 del rol Recepcionista.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

stc_exigir_permiso( 'stc_consultar_disponibilidad' );

// Fechas por defecto: hoy y mañana.
$llegada = isset( $_GET['llegada'] ) ? sanitize_text_field( $_GET['llegada'] ) : date( 'Y-m-d' );
$salida  = isset( $_GET['salida'] ) ? sanitize_text_field( $_GET['salida'] ) : date( 'Y-m-d', strtotime( '+1 day' ) );
$tipo    = isset( $_GET['tipo'] ) ? sanitize_text_field( $_GET['tipo'] ) : '';

$error = '';
if ( strtotime( $salida ) <= strtotime( $llegada ) ) {
    $error   = 'La fecha de salida debe ser posterior a la de llegada.';
    $salida  = date( 'Y-m-d', strtotime( $llegada . ' +1 day' ) );
}

$disponibles = stc_habitaciones_disponibles( $llegada, $salida );
$ocupadas    = stc_habitaciones_ocupadas( $llegada, $salida );
$noches      = stc_calcular_noches( $llegada, $salida );

// Filtro opcional por tipo de habitacion.
if ( '' !== $tipo ) {
    $disponibles = array_filter(
        $disponibles,
        function ( $h ) use ( $tipo ) {
            return $h->tipo === $tipo;
        }
    );
}
?>
<div class="wrap stc-wrap">
    <h1>Consultar disponibilidad</h1>
    <p class="description">Selecciona un rango de fechas para ver que habitaciones estan libres.</p>

    <?php if ( $error ) : ?>
        <?php stc_aviso( $error, 'error' ); ?>
    <?php endif; ?>

    <form method="get" class="stc-caja">
        <input type="hidden" name="page" value="stc-disponibilidad">
        <table class="form-table">
            <tr>
                <th><label for="llegada">Fecha de llegada</label></th>
                <td><input type="date" name="llegada" id="llegada" value="<?php echo esc_attr( $llegada ); ?>" required></td>
                <th><label for="salida">Fecha de salida</label></th>
                <td><input type="date" name="salida" id="salida" value="<?php echo esc_attr( $salida ); ?>" required></td>
                <th><label for="tipo">Tipo</label></th>
                <td>
                    <select name="tipo" id="tipo">
                        <option value="">Todos</option>
                        <?php foreach ( stc_tipos_habitacion() as $t ) : ?>
                            <option value="<?php echo esc_attr( $t ); ?>" <?php selected( $tipo, $t ); ?>>
                                <?php echo esc_html( $t ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><button type="submit" class="button button-primary">Consultar</button></td>
            </tr>
        </table>
    </form>

    <div class="stc-resumen">
        <div class="stc-tarjeta stc-verde">
            <span class="stc-numero"><?php echo count( $disponibles ); ?></span>
            <span class="stc-etiqueta">Habitaciones disponibles</span>
        </div>
        <div class="stc-tarjeta stc-rojo">
            <span class="stc-numero"><?php echo count( $ocupadas ); ?></span>
            <span class="stc-etiqueta">Habitaciones ocupadas</span>
        </div>
        <div class="stc-tarjeta stc-azul">
            <span class="stc-numero"><?php echo (int) $noches; ?></span>
            <span class="stc-etiqueta">Noches consultadas</span>
        </div>
    </div>

    <h2>Disponibles del <?php echo esc_html( $llegada ); ?> al <?php echo esc_html( $salida ); ?></h2>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Numero</th>
                <th>Tipo</th>
                <th>Capacidad</th>
                <th>Precio / noche</th>
                <th>Total <?php echo (int) $noches; ?> noche(s)</th>
                <th>Descripcion</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
        <?php if ( empty( $disponibles ) ) : ?>
            <tr><td colspan="7">No hay habitaciones disponibles con los criterios seleccionados.</td></tr>
        <?php else : ?>
            <?php foreach ( $disponibles as $h ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $h->numero ); ?></strong></td>
                    <td><?php echo esc_html( $h->tipo ); ?></td>
                    <td><?php echo esc_html( $h->capacidad ); ?> huesped(es)</td>
                    <td><?php echo esc_html( stc_precio( $h->precio_noche ) ); ?></td>
                    <td><strong><?php echo esc_html( stc_precio( $h->precio_noche * $noches ) ); ?></strong></td>
                    <td><?php echo esc_html( $h->descripcion ); ?></td>
                    <td>
                        <?php if ( current_user_can( 'stc_registrar_reservas' ) ) : ?>
                            <a class="button button-primary"
                               href="<?php echo esc_url( admin_url( 'admin.php?page=stc-nueva-reserva&llegada=' . $llegada . '&salida=' . $salida . '&habitacion=' . $h->id ) ); ?>">
                               Reservar
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>

    <?php if ( ! empty( $ocupadas ) ) : ?>
        <h2>Ocupadas en ese rango</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Numero</th>
                    <th>Tipo</th>
                    <th>Reserva</th>
                    <th>Cliente</th>
                    <th>Llegada</th>
                    <th>Salida</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ( $ocupadas as $o ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $o->numero ); ?></strong></td>
                    <td><?php echo esc_html( $o->tipo ); ?></td>
                    <td>#<?php echo esc_html( $o->reserva_id ); ?></td>
                    <td><?php echo esc_html( $o->cliente_nombre ); ?></td>
                    <td><?php echo esc_html( $o->fecha_llegada ); ?></td>
                    <td><?php echo esc_html( $o->fecha_salida ); ?></td>
                    <td><?php echo wp_kses_post( stc_etiqueta_estado( $o->estado ) ); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
