<?php
/**
 * Vista: registrar una reserva.
 * Requerimientos 2 y 3 del rol Recepcionista:
 *   - Calcular el precio total para un cliente.
 *   - Registrar una reserva.
 *
 * El formulario funciona en dos pasos:
 *   Paso 1: se indican las fechas y el tipo de cliente.
 *   Paso 2: se muestran las habitaciones libres en ese rango y se
 *           completan los datos del cliente. El precio se calcula
 *           en vivo y se vuelve a validar en el servidor al guardar.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

stc_exigir_permiso( 'stc_registrar_reservas' );

$mensaje      = '';
$tipo_mensaje = 'success';
$reserva_id   = 0;

// Valores del formulario (pueden venir de la pantalla de disponibilidad).
$llegada       = isset( $_REQUEST['llegada'] ) ? sanitize_text_field( $_REQUEST['llegada'] ) : date( 'Y-m-d' );
$salida        = isset( $_REQUEST['salida'] ) ? sanitize_text_field( $_REQUEST['salida'] ) : date( 'Y-m-d', strtotime( '+1 day' ) );
$tipo_cliente  = isset( $_REQUEST['cliente_tipo'] ) ? sanitize_text_field( $_REQUEST['cliente_tipo'] ) : 'esporadico';
$num_huespedes = isset( $_REQUEST['num_huespedes'] ) ? (int) $_REQUEST['num_huespedes'] : 1;
$preseleccion  = isset( $_GET['habitacion'] ) ? array( (int) $_GET['habitacion'] ) : array();

$paso = 1;
if ( isset( $_POST['stc_buscar'] ) || isset( $_POST['stc_guardar_reserva'] ) || ! empty( $preseleccion ) ) {
    $paso = 2;
}

/* ------------------------------------------------------------------
 * Procesamiento del guardado
 * ------------------------------------------------------------------ */

if ( isset( $_POST['stc_guardar_reserva'] ) ) {

    // Proteccion CSRF.
    if ( ! isset( $_POST['stc_nonce'] ) || ! wp_verify_nonce( $_POST['stc_nonce'], 'stc_registrar_reserva' ) ) {
        wp_die( 'Verificacion de seguridad fallida.' );
    }

    $resultado = stc_registrar_reserva(
        array(
            'cliente_nombre'    => $_POST['cliente_nombre'],
            'cliente_documento' => $_POST['cliente_documento'],
            'cliente_tipo'      => $_POST['cliente_tipo'],
            'cliente_email'     => isset( $_POST['cliente_email'] ) ? $_POST['cliente_email'] : '',
            'cliente_telefono'  => isset( $_POST['cliente_telefono'] ) ? $_POST['cliente_telefono'] : '',
            'fecha_llegada'     => $_POST['fecha_llegada'],
            'fecha_salida'      => $_POST['fecha_salida'],
            'num_huespedes'     => $_POST['num_huespedes'],
            'habitaciones'      => isset( $_POST['habitaciones'] ) ? $_POST['habitaciones'] : array(),
        )
    );

    $mensaje      = $resultado['mensaje'];
    $tipo_mensaje = $resultado['exito'] ? 'success' : 'error';

    if ( $resultado['exito'] ) {
        $reserva_id   = $resultado['reserva_id'];
        $paso         = 1; // Se reinicia el formulario.
        $preseleccion = array();
    }
}

$disponibles = ( 2 === $paso ) ? stc_habitaciones_disponibles( $llegada, $salida ) : array();
$noches      = stc_calcular_noches( $llegada, $salida );
?>
<div class="wrap stc-wrap">
    <h1>Registrar reserva</h1>

    <?php if ( $mensaje ) : ?>
        <div class="notice notice-<?php echo esc_attr( $tipo_mensaje ); ?>">
            <p><?php echo esc_html( $mensaje ); ?></p>
            <?php if ( $reserva_id ) : ?>
                <p>
                    <a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=stc-pago&reserva=' . $reserva_id ) ); ?>">Registrar pago</a>
                    <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=stc-reservas' ) ); ?>">Ver reservas</a>
                </p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- PASO 1: fechas y tipo de cliente -->
    <form method="post" class="stc-caja">
        <h2>1. Fechas de la estadia</h2>
        <table class="form-table">
            <tr>
                <th><label for="llegada">Fecha de llegada *</label></th>
                <td><input type="date" name="llegada" id="llegada" value="<?php echo esc_attr( $llegada ); ?>" required></td>
            </tr>
            <tr>
                <th><label for="salida">Fecha de salida *</label></th>
                <td><input type="date" name="salida" id="salida" value="<?php echo esc_attr( $salida ); ?>" required></td>
            </tr>
            <tr>
                <th><label for="num_huespedes">Cantidad de huespedes *</label></th>
                <td><input type="number" name="num_huespedes" id="num_huespedes" value="<?php echo esc_attr( $num_huespedes ); ?>" min="1" max="20" required></td>
            </tr>
            <tr>
                <th><label for="cliente_tipo">Tipo de cliente *</label></th>
                <td>
                    <select name="cliente_tipo" id="cliente_tipo">
                        <?php foreach ( stc_tipos_cliente() as $clave => $etiqueta ) : ?>
                            <option value="<?php echo esc_attr( $clave ); ?>" <?php selected( $tipo_cliente, $clave ); ?>>
                                <?php echo esc_html( $etiqueta ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">
                        Los clientes frecuentes reciben un <?php echo (int) STC_DESCUENTO_FRECUENTE; ?>% de descuento sobre el total.
                    </p>
                </td>
            </tr>
        </table>
        <?php submit_button( 'Buscar habitaciones disponibles', 'secondary', 'stc_buscar' ); ?>
    </form>

    <?php if ( 2 === $paso ) : ?>

        <!-- PASO 2: habitaciones y datos del cliente -->
        <form method="post" class="stc-caja" id="stc-form-reserva">
            <?php wp_nonce_field( 'stc_registrar_reserva', 'stc_nonce' ); ?>
            <input type="hidden" name="fecha_llegada" value="<?php echo esc_attr( $llegada ); ?>">
            <input type="hidden" name="fecha_salida" value="<?php echo esc_attr( $salida ); ?>">
            <input type="hidden" name="num_huespedes" value="<?php echo esc_attr( $num_huespedes ); ?>">
            <input type="hidden" name="cliente_tipo" value="<?php echo esc_attr( $tipo_cliente ); ?>">
            <input type="hidden" id="stc-noches" value="<?php echo esc_attr( $noches ); ?>">
            <input type="hidden" id="stc-descuento" value="<?php echo ( 'frecuente' === $tipo_cliente ) ? (int) STC_DESCUENTO_FRECUENTE : 0; ?>">

            <h2>2. Habitaciones disponibles (<?php echo (int) $noches; ?> noche<?php echo $noches > 1 ? 's' : ''; ?>)</h2>

            <?php if ( empty( $disponibles ) ) : ?>
                <p>No hay habitaciones disponibles en ese rango de fechas. Modifica las fechas e intenta nuevamente.</p>
            <?php else : ?>
                <p class="description">Puedes seleccionar mas de una habitacion si el grupo lo requiere.</p>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width:60px;">Elegir</th>
                            <th>Numero</th>
                            <th>Tipo</th>
                            <th>Capacidad</th>
                            <th>Precio / noche</th>
                            <th>Subtotal estadia</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $disponibles as $h ) : ?>
                        <tr>
                            <td>
                                <input type="checkbox"
                                       class="stc-hab"
                                       name="habitaciones[]"
                                       value="<?php echo esc_attr( $h->id ); ?>"
                                       data-precio="<?php echo esc_attr( $h->precio_noche ); ?>"
                                       data-capacidad="<?php echo esc_attr( $h->capacidad ); ?>"
                                       <?php checked( in_array( (int) $h->id, $preseleccion, true ) ); ?>>
                            </td>
                            <td><strong><?php echo esc_html( $h->numero ); ?></strong></td>
                            <td><?php echo esc_html( $h->tipo ); ?></td>
                            <td><?php echo esc_html( $h->capacidad ); ?> huesped(es)</td>
                            <td><?php echo esc_html( stc_precio( $h->precio_noche ) ); ?></td>
                            <td><?php echo esc_html( stc_precio( $h->precio_noche * $noches ) ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Calculo del precio total en vivo -->
                <div class="stc-total" id="stc-panel-total">
                    <h3>Precio total</h3>
                    <p>Habitaciones seleccionadas: <strong id="stc-num-hab">0</strong>
                       &nbsp;|&nbsp; Capacidad total: <strong id="stc-cap">0</strong> huesped(es)</p>
                    <p>Subtotal: <strong id="stc-subtotal">$0</strong></p>
                    <p>Descuento cliente <?php echo esc_html( stc_tipos_cliente()[ $tipo_cliente ] ); ?>
                       (<span id="stc-pct">0</span>%): <strong id="stc-desc">$0</strong></p>
                    <p class="stc-grande">TOTAL A PAGAR: <strong id="stc-total">$0</strong></p>
                </div>

                <h2>3. Datos del cliente</h2>
                <table class="form-table">
                    <tr>
                        <th><label for="cliente_nombre">Nombre completo *</label></th>
                        <td><input type="text" name="cliente_nombre" id="cliente_nombre" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="cliente_documento">Documento *</label></th>
                        <td><input type="text" name="cliente_documento" id="cliente_documento" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="cliente_email">Correo electronico</label></th>
                        <td><input type="email" name="cliente_email" id="cliente_email" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="cliente_telefono">Telefono</label></th>
                        <td><input type="text" name="cliente_telefono" id="cliente_telefono" class="regular-text"></td>
                    </tr>
                </table>

                <?php submit_button( 'Registrar reserva', 'primary', 'stc_guardar_reserva' ); ?>
            <?php endif; ?>
        </form>

        <script>
        // Calculo del precio en el navegador, solo informativo.
        // El calculo definitivo se realiza en el servidor al guardar.
        (function () {
            var noches    = parseInt(document.getElementById('stc-noches').value, 10) || 0;
            var pctDesc   = parseFloat(document.getElementById('stc-descuento').value) || 0;
            var checkboxes = document.querySelectorAll('.stc-hab');

            function formato(valor) {
                return '$' + Math.round(valor).toLocaleString('es-CO');
            }

            function recalcular() {
                var subtotal = 0, capacidad = 0, cantidad = 0;

                checkboxes.forEach(function (cb) {
                    if (cb.checked) {
                        subtotal  += parseFloat(cb.dataset.precio) * noches;
                        capacidad += parseInt(cb.dataset.capacidad, 10);
                        cantidad  += 1;
                    }
                });

                var descuento = subtotal * pctDesc / 100;

                document.getElementById('stc-num-hab').textContent  = cantidad;
                document.getElementById('stc-cap').textContent      = capacidad;
                document.getElementById('stc-subtotal').textContent = formato(subtotal);
                document.getElementById('stc-pct').textContent      = pctDesc;
                document.getElementById('stc-desc').textContent     = '-' + formato(descuento);
                document.getElementById('stc-total').textContent    = formato(subtotal - descuento);
            }

            checkboxes.forEach(function (cb) {
                cb.addEventListener('change', recalcular);
            });

            recalcular();
        })();
        </script>

    <?php endif; ?>
</div>
