<?php
/**
 * Vista: pasarela de pagos simulada.
 * Requerimientos: registrar un pago y asociarlo a la reserva.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

stc_exigir_permiso( 'stc_registrar_pagos' );

$reserva_id = isset( $_REQUEST['reserva'] ) ? (int) $_REQUEST['reserva'] : 0;
$reserva    = stc_obtener_reserva( $reserva_id );

if ( ! $reserva ) {
    echo '<div class="wrap"><h1>Registrar pago</h1>';
    stc_aviso( 'La reserva indicada no existe.', 'error' );
    echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=stc-reservas' ) ) . '">Volver a reservas</a></p></div>';
    return;
}

/* --- Procesamiento del pago --- */
if ( isset( $_POST['stc_pagar'] ) ) {

    if ( ! isset( $_POST['stc_nonce_pago'] ) || ! wp_verify_nonce( $_POST['stc_nonce_pago'], 'stc_pago_' . $reserva_id ) ) {
        wp_die( 'Verificacion de seguridad fallida.' );
    }

    $resultado = stc_procesar_pago(
        $reserva_id,
        array(
            'titular'        => $_POST['titular'],
            'numero_tarjeta' => $_POST['numero_tarjeta'],
            'cvv'            => $_POST['cvv'],
            'vencimiento'    => $_POST['vencimiento'],
            'monto'          => $_POST['monto'],
        )
    );

    stc_aviso( $resultado['mensaje'], $resultado['exito'] ? 'success' : 'error' );

    // Se recarga la reserva para reflejar el nuevo estado.
    $reserva = stc_obtener_reserva( $reserva_id );
}

$habitaciones = stc_habitaciones_de_reserva( $reserva_id );
$pagos        = stc_pagos_de_reserva( $reserva_id );
$pagado       = stc_total_pagado( $reserva_id );
$saldo        = stc_saldo_pendiente( $reserva_id );
$noches       = stc_calcular_noches( $reserva->fecha_llegada, $reserva->fecha_salida );
?>
<div class="wrap stc-wrap">
    <h1>Pasarela de pagos (simulada)</h1>
    <p><a href="<?php echo esc_url( admin_url( 'admin.php?page=stc-reservas' ) ); ?>">&larr; Volver a reservas</a></p>

    <div class="stc-columnas">

        <!-- Resumen de la reserva -->
        <div class="stc-caja">
            <h2>Reserva #<?php echo esc_html( $reserva->id ); ?></h2>

            <table class="widefat">
                <tr><td><strong>Cliente</strong></td><td><?php echo esc_html( $reserva->cliente_nombre ); ?></td></tr>
                <tr><td><strong>Documento</strong></td><td><?php echo esc_html( $reserva->cliente_documento ); ?></td></tr>
                <tr><td><strong>Tipo de cliente</strong></td><td><?php echo esc_html( stc_tipos_cliente()[ $reserva->cliente_tipo ] ); ?></td></tr>
                <tr><td><strong>Habitaciones</strong></td><td><?php echo esc_html( stc_resumen_habitaciones( $reserva->id ) ); ?></td></tr>
                <tr><td><strong>Huespedes</strong></td><td><?php echo esc_html( $reserva->num_huespedes ); ?></td></tr>
                <tr><td><strong>Estadia</strong></td><td><?php echo esc_html( $reserva->fecha_llegada ); ?> al <?php echo esc_html( $reserva->fecha_salida ); ?> (<?php echo (int) $noches; ?> noches)</td></tr>
                <tr><td><strong>Subtotal</strong></td><td><?php echo esc_html( stc_precio( $reserva->subtotal ) ); ?></td></tr>
                <tr><td><strong>Descuento</strong></td><td>-<?php echo esc_html( stc_precio( $reserva->descuento ) ); ?></td></tr>
                <tr><td><strong>Total</strong></td><td><strong><?php echo esc_html( stc_precio( $reserva->total ) ); ?></strong></td></tr>
                <tr><td><strong>Pagado</strong></td><td><?php echo esc_html( stc_precio( $pagado ) ); ?></td></tr>
                <tr><td><strong>Saldo pendiente</strong></td><td><strong><?php echo esc_html( stc_precio( $saldo ) ); ?></strong></td></tr>
                <tr><td><strong>Estado</strong></td><td><?php echo wp_kses_post( stc_etiqueta_estado( $reserva->estado ) ); ?></td></tr>
            </table>
        </div>

        <!-- Formulario de pago -->
        <div class="stc-caja">
            <h2>Registrar pago</h2>

            <?php if ( $saldo <= 0 ) : ?>
                <p>Esta reserva se encuentra pagada en su totalidad.</p>
            <?php else : ?>
                <div class="stc-nota">
                    <strong>Entorno de prueba.</strong> No se realiza ninguna conexion real con una entidad financiera.
                    Cualquier tarjeta de 16 digitos es aprobada. Para simular un rechazo, usa una tarjeta
                    terminada en <code>0000</code>, por ejemplo <code>4111 1111 1111 0000</code>.
                </div>

                <form method="post">
                    <?php wp_nonce_field( 'stc_pago_' . $reserva_id, 'stc_nonce_pago' ); ?>
                    <input type="hidden" name="reserva" value="<?php echo esc_attr( $reserva_id ); ?>">

                    <table class="form-table">
                        <tr>
                            <th><label for="monto">Monto a pagar *</label></th>
                            <td>
                                <input type="number" name="monto" id="monto" step="any" min="1"
                                       max="<?php echo esc_attr( $saldo ); ?>"
                                       value="<?php echo esc_attr( $saldo ); ?>" required>
                                <p class="description">Se admiten abonos parciales. Saldo pendiente: <?php echo esc_html( stc_precio( $saldo ) ); ?>.</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="titular">Titular de la tarjeta *</label></th>
                            <td><input type="text" name="titular" id="titular" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label for="numero_tarjeta">Numero de tarjeta *</label></th>
                            <td><input type="text" name="numero_tarjeta" id="numero_tarjeta" class="regular-text"
                                       placeholder="4111 1111 1111 1111" maxlength="19" required></td>
                        </tr>
                        <tr>
                            <th><label for="vencimiento">Vencimiento (MM/AA) *</label></th>
                            <td><input type="text" name="vencimiento" id="vencimiento" placeholder="12/28" maxlength="5" required></td>
                        </tr>
                        <tr>
                            <th><label for="cvv">CVV *</label></th>
                            <td><input type="text" name="cvv" id="cvv" maxlength="4" required></td>
                        </tr>
                    </table>

                    <?php submit_button( 'Procesar pago', 'primary', 'stc_pagar' ); ?>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <h2>Pagos registrados</h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr><th>Referencia</th><th>Monto</th><th>Metodo</th><th>Titular</th><th>Tarjeta</th><th>Estado</th><th>Fecha</th></tr>
        </thead>
        <tbody>
        <?php if ( empty( $pagos ) ) : ?>
            <tr><td colspan="7">Aun no se han registrado pagos para esta reserva.</td></tr>
        <?php else : ?>
            <?php foreach ( $pagos as $p ) : ?>
                <tr>
                    <td><code><?php echo esc_html( $p->referencia ); ?></code></td>
                    <td><strong><?php echo esc_html( stc_precio( $p->monto ) ); ?></strong></td>
                    <td><?php echo esc_html( ucfirst( $p->metodo ) ); ?></td>
                    <td><?php echo esc_html( $p->titular ); ?></td>
                    <td>**** <?php echo esc_html( $p->ultimos_digitos ); ?></td>
                    <td><span class="stc-badge stc-badge-pagada"><?php echo esc_html( ucfirst( $p->estado ) ); ?></span></td>
                    <td><?php echo esc_html( $p->fecha_pago ); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
