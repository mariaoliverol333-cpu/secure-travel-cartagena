<?php
/**
 * Vista: eliminar una reserva indicando el numero de habitacion.
 * Requerimiento 4 del rol Recepcionista.
 *
 * El flujo es en dos pasos para evitar borrados accidentales:
 *   1. Se busca por numero de habitacion.
 *   2. Se muestran las reservas encontradas y se confirma cual eliminar.
 *
 * @package SecureTravelCartagena
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

stc_exigir_permiso( 'stc_eliminar_reservas' );

$numero      = isset( $_REQUEST['numero'] ) ? sanitize_text_field( $_REQUEST['numero'] ) : '';
$encontradas = array();
$buscado     = false;

/* --- Confirmacion de eliminacion --- */
if ( isset( $_POST['stc_confirmar_eliminacion'] ) ) {

    if ( ! isset( $_POST['stc_nonce_eliminar'] ) || ! wp_verify_nonce( $_POST['stc_nonce_eliminar'], 'stc_eliminar_por_habitacion' ) ) {
        wp_die( 'Verificacion de seguridad fallida.' );
    }

    $reserva_id = (int) $_POST['reserva_id'];
    $resultado  = stc_eliminar_reserva( $reserva_id );
    stc_aviso( $resultado['mensaje'], $resultado['exito'] ? 'success' : 'error' );
    $numero = ''; // Se limpia la busqueda tras eliminar.
}

/* --- Busqueda por numero de habitacion --- */
if ( isset( $_POST['stc_buscar_habitacion'] ) && '' !== $numero ) {
    $buscado    = true;
    $habitacion = stc_obtener_habitacion_por_numero( $numero );

    if ( ! $habitacion ) {
        stc_aviso( 'No existe ninguna habitacion con el numero ' . $numero . '.', 'error' );
    } else {
        $encontradas = stc_buscar_reservas_por_habitacion( $numero );
        if ( empty( $encontradas ) ) {
            stc_aviso( 'La habitacion ' . $numero . ' no tiene reservas vigentes.', 'warning' );
        }
    }
}
?>
<div class="wrap stc-wrap">
    <h1>Eliminar reserva</h1>
    <p class="description">Indica el numero de habitacion para localizar la reserva que deseas eliminar.</p>

    <form method="post" class="stc-caja">
        <table class="form-table">
            <tr>
                <th><label for="numero">Numero de habitacion *</label></th>
                <td>
                    <input type="text" name="numero" id="numero" class="regular-text"
                           value="<?php echo esc_attr( $numero ); ?>" placeholder="Ej: 103" required>
                    <p class="description">Se mostraran las reservas vigentes asociadas a esa habitacion.</p>
                </td>
            </tr>
        </table>
        <?php submit_button( 'Buscar reservas', 'secondary', 'stc_buscar_habitacion' ); ?>
    </form>

    <?php if ( ! empty( $encontradas ) ) : ?>
        <h2>Reservas de la habitacion <?php echo esc_html( $numero ); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Documento</th>
                    <th>Habitaciones de la reserva</th>
                    <th>Llegada</th>
                    <th>Salida</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Accion</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ( $encontradas as $r ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $r->id ); ?></strong></td>
                    <td><?php echo esc_html( $r->cliente_nombre ); ?></td>
                    <td><?php echo esc_html( $r->cliente_documento ); ?></td>
                    <td><?php echo esc_html( stc_resumen_habitaciones( $r->id ) ); ?></td>
                    <td><?php echo esc_html( $r->fecha_llegada ); ?></td>
                    <td><?php echo esc_html( $r->fecha_salida ); ?></td>
                    <td><?php echo esc_html( stc_precio( $r->total ) ); ?></td>
                    <td><?php echo wp_kses_post( stc_etiqueta_estado( $r->estado ) ); ?></td>
                    <td>
                        <form method="post" style="margin:0;">
                            <?php wp_nonce_field( 'stc_eliminar_por_habitacion', 'stc_nonce_eliminar' ); ?>
                            <input type="hidden" name="reserva_id" value="<?php echo esc_attr( $r->id ); ?>">
                            <button type="submit"
                                    name="stc_confirmar_eliminacion"
                                    class="button stc-boton-rojo"
                                    onclick="return confirm('Eliminar la reserva #<?php echo (int) $r->id; ?> de <?php echo esc_js( $r->cliente_nombre ); ?>?');">
                                Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p class="description">
            Al eliminar una reserva se borran tambien sus pagos asociados y se liberan
            las habitaciones para nuevas reservas.
        </p>
    <?php endif; ?>
</div>
