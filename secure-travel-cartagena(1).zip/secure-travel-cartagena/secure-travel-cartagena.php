<?php
/**
 * Plugin Name:       Secure Travel Cartagena - Sistema de Reservas
 * Plugin URI:        https://github.com/USUARIO/secure-travel-cartagena
 * Description:       Sistema de reservas de habitaciones para Secure Travel Cartagena. Gestion de habitaciones, control de disponibilidad, roles de recepcionista y administrador, informes de ocupacion y pasarela de pagos simulada.
 * Version:           1.1.0
 * Author:            Maria Olivero
 * Text Domain:       secure-travel-cartagena
 * Requires at least: 6.0
 * Requires PHP:      7.4
 *
 * @package SecureTravelCartagena
 */

// Seguridad: impide el acceso directo al archivo desde el navegador.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* ------------------------------------------------------------------
 * CONSTANTES DEL PLUGIN
 * ------------------------------------------------------------------ */

define( 'STC_VERSION', '1.1.0' );
define( 'STC_PATH', plugin_dir_path( __FILE__ ) );
define( 'STC_URL', plugin_dir_url( __FILE__ ) );

// Regla de negocio: descuento aplicado a los clientes frecuentes.
define( 'STC_DESCUENTO_FRECUENTE', 10 ); // porcentaje

/* ------------------------------------------------------------------
 * CARGA DE ARCHIVOS
 * ------------------------------------------------------------------
 * El plugin se organiza en capas:
 *   includes/  -> instalacion y logica de negocio (sin HTML)
 *   admin/     -> vistas del panel de administracion (HTML)
 * De esta forma la logica se puede probar y reutilizar de forma
 * independiente de la interfaz.
 */

require_once STC_PATH . 'includes/instalador.php';
require_once STC_PATH . 'includes/funciones-habitaciones.php';
require_once STC_PATH . 'includes/funciones-reservas.php';
require_once STC_PATH . 'includes/funciones-pagos.php';
require_once STC_PATH . 'includes/menus.php';

/* ------------------------------------------------------------------
 * ACTIVACION Y DESACTIVACION
 * ------------------------------------------------------------------ */

register_activation_hook( __FILE__, 'stc_activar_plugin' );
register_deactivation_hook( __FILE__, 'stc_desactivar_plugin' );

/* ------------------------------------------------------------------
 * ESTILOS DEL PANEL
 * ------------------------------------------------------------------
 * Se encolan solo en las pantallas del plugin, no en todo el admin.
 */

add_action( 'admin_enqueue_scripts', 'stc_cargar_estilos_admin' );
function stc_cargar_estilos_admin( $hook ) {
    if ( strpos( $hook, 'stc-' ) === false ) {
        return;
    }
    wp_enqueue_style(
        'stc-admin',
        STC_URL . 'assets/css/admin.css',
        array(),
        STC_VERSION
    );
}
